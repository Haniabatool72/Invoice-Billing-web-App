"use strict";

/* ---------- Helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const KEY = "ledgerly.invoices.v1";
const money = n => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n || 0);
const iso = d => d.toISOString().slice(0, 10);
const today = () => iso(new Date());
const addDays = (n, from = new Date()) => { const d = new Date(from); d.setDate(d.getDate() + n); return iso(d); };
const fmtDate = s => s ? new Date(s + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Math.random().toString(36).slice(2, 9);

/* ---------- Data ---------- */
function seed() {
  const mk = (n, client, email, phone, address, issued, due, status, items, tax = 10) =>
    ({ id: uid(), number: `INV-${String(n).padStart(4, "0")}`, client, email, phone, address, issued, due, status, tax, discount: 0, notes: "Payment due within 14 days. Thank you for your business.",
       items: items.map(([description, qty, rate]) => ({ description, qty, rate })) });
  return [
    mk(1, "Northwind Traders", "ap@northwind.com", "+1 555 010 2211", "88 Dock Road, Portland, OR 97201", addDays(-40), addDays(-26), "pending", [["Brand identity design", 1, 2400], ["Logo variations", 3, 150]]),
    mk(2, "Helix Labs", "finance@helixlabs.io", "+44 20 7946 0123", "5 Kings Yard, London N1 9AB", addDays(-20), addDays(-6), "paid", [["Website development", 40, 85], ["Hosting setup", 1, 200]]),
    mk(3, "Bluebird Cafe", "hello@bluebird.cafe", "+1 555 014 7788", "210 Elm Street, Austin, TX 78701", addDays(-5), addDays(9), "pending", [["Menu redesign", 1, 650], ["Print-ready files", 2, 90]], 8)
  ];
}
function load() {
  try { const d = JSON.parse(localStorage.getItem(KEY)); if (Array.isArray(d)) return d.map(i => ({ phone: "", address: "", ...i })); } catch {}
  return seed();
}
function persist() { try { localStorage.setItem(KEY, JSON.stringify(invoices)); return true; } catch { toast("Couldn't save: browser storage is unavailable"); return false; } }

let invoices = load();
let current = null;   // invoice being edited
let isNew = false;

const r2 = n => Math.round((n + Number.EPSILON) * 100) / 100;
const line = x => r2((+x.qty || 0) * (+x.rate || 0));
const totals = i => {
  const sub = r2(i.items.reduce((s, x) => s + line(x), 0));
  const disc = r2(sub * (+i.discount || 0) / 100);
  const tax = r2((sub - disc) * (+i.tax || 0) / 100);
  return { sub, disc, tax, total: r2(sub - disc + tax) };
};
const statusOf = i => i.status === "paid" ? "paid" : (i.due < today() ? "overdue" : "pending");
const nextNumber = () => `INV-${String(Math.max(0, ...invoices.map(i => parseInt(i.number.replace(/\D/g, "")) || 0)) + 1).padStart(4, "0")}`;

/* ---------- Views ---------- */
function show(view) {
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${view}`));
  $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.view === view));
  window.scrollTo({ top: 0 });
}
let toastTimer;
function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
}

/* ---------- List ---------- */
function renderStats() {
  const sum = l => l.reduce((s, i) => s + totals(i).total, 0);
  const paid = invoices.filter(i => statusOf(i) === "paid");
  const open = invoices.filter(i => statusOf(i) !== "paid");
  const late = open.filter(i => statusOf(i) === "overdue");
  const pct = invoices.length ? Math.round(paid.length / invoices.length * 100) : 0;
  $("#stats").innerHTML = `
    <div class="stat hero"><span>Total revenue</span><strong>${money(sum(paid))}</strong><small>Collected from paid invoices</small></div>
    <div class="stat"><span>Total invoices</span><strong>${invoices.length}</strong><small>${money(sum(invoices))} billed</small></div>
    <div class="stat"><span>Paid invoices</span><strong>${paid.length}</strong><small>${pct}% of all invoices</small></div>
    <div class="stat"><span>Pending invoices</span><strong>${open.length}</strong><small>${money(sum(open))} outstanding${late.length ? `, ${late.length} overdue` : ""}</small></div>`;
  const recent = [...invoices].sort((a, b) => b.issued.localeCompare(a.issued)).slice(0, 5);
  $("#recent").innerHTML = recent.map(i => {
    const s = statusOf(i);
    return `<li data-id="${i.id}" tabindex="0"><span class="avatar">${esc(i.client.trim().charAt(0).toUpperCase() || "?")}</span>
      <span class="who"><strong>${esc(i.client)}</strong><small>${esc(i.number)}, due ${fmtDate(i.due)}</small></span>
      <span class="amt">${money(totals(i).total)}</span><span class="badge ${s}">${s}</span></li>`;
  }).join("");
  $("#recentEmpty").hidden = recent.length > 0;
}
function renderList() {
  renderStats();
  const q = $("#search").value.trim().toLowerCase(), f = $("#filter").value, sc = $("#scope").value, dir = $("#sort").value === "old" ? 1 : -1;
  const hay = i => sc === "customer" ? i.client : sc === "number" ? i.number : `${i.client} ${i.number} ${i.email} ${i.phone}`;
  const list = invoices
    .filter(i => (f === "all" || statusOf(i) === f) && hay(i).toLowerCase().includes(q))
    .sort((a, b) => dir * (a.issued.localeCompare(b.issued) || a.number.localeCompare(b.number)));
  $("#rows").innerHTML = list.map(i => {
    const s = statusOf(i);
    return `<tr data-id="${i.id}">
      <td><strong>${esc(i.number)}</strong></td>
      <td class="client">${esc(i.client)}<small>${esc(i.email)}</small></td>
      <td>${fmtDate(i.issued)}</td><td>${fmtDate(i.due)}</td>
      <td class="num">${money(totals(i).total)}</td>
      <td><span class="badge ${s}">${s}</span></td>
      <td class="num"><span class="row-actions">
        <button class="icon-btn" data-act="view">View</button>
        <button class="icon-btn" data-act="edit">Edit</button>
        <button class="icon-btn" data-act="print">Print</button>
        <button class="icon-btn" data-act="pdf">PDF</button>
        ${s !== "paid" ? '<button class="icon-btn" data-act="paid">Mark paid</button>' : ""}
        <button class="icon-btn danger" data-act="delete">Delete</button>
      </span></td></tr>`;
  }).join("");
  $("#empty").hidden = list.length > 0;
  $("#count").textContent = `Showing ${list.length} of ${invoices.length} invoice${invoices.length === 1 ? "" : "s"}`;
}

/* ---------- View / delete ---------- */
let viewing = null;
function viewInvoice(id) {
  viewing = invoices.find(i => i.id === id); if (!viewing) return;
  $("#viewTitle").textContent = viewing.number;
  $("#viewBody").innerHTML = invoiceHTML(viewing);
  $("#viewDlg").showModal();
}
function deleteInvoice(inv) {
  if (!confirm(`Delete ${inv.number}? This can't be undone.`)) return false;
  invoices = invoices.filter(i => i.id !== inv.id); persist(); renderList(); toast(`${inv.number} deleted`); return true;
}
$("#viewDlg").addEventListener("click", e => {
  const dlg = e.currentTarget, act = e.target.dataset.v;
  if (e.target === dlg || act === "close") return dlg.close();
  if (!act || !viewing) return;
  if (act === "print") { dlg.close(); printInvoice(viewing); }
  if (act === "pdf") downloadPDF(viewing);
  if (act === "edit") { dlg.close(); openEditor(viewing.id); }
  if (act === "delete" && deleteInvoice(viewing)) dlg.close();
});

/* ---------- Editor ---------- */
function openEditor(id) {
  isNew = !id;
  current = id
    ? structuredClone(invoices.find(i => i.id === id))
    : { id: uid(), number: nextNumber(), client: "", email: "", phone: "", address: "", issued: today(), due: addDays(14), status: "pending", tax: 0, discount: 0, notes: "", items: [{ description: "", qty: 1, rate: 0 }] };
  $("#editorTitle").textContent = isNew ? "New invoice" : `Edit ${current.number}`;
  const f = $("#form");
  ["number", "status", "issued", "due", "client", "email", "phone", "address", "tax", "discount", "notes"].forEach(k => (f.elements[k].value = current[k] ?? ""));
  $$(".err").forEach(e => (e.textContent = ""));
  $$(".invalid").forEach(el => { el.classList.remove("invalid"); el.removeAttribute("aria-invalid"); });
  renderItems(); renderPreview(); show("editor");
}
function renderItems() {
  $("#itemsErr").textContent = "";
  $("#items").innerHTML = current.items.map((it, n) => `
    <tr class="item-row" data-n="${n}">
      <td data-label="Product / service"><input data-k="description" placeholder="e.g. Website design" value="${esc(it.description)}" aria-label="Product or service"></td>
      <td data-label="Quantity"><input data-k="qty" type="number" min="0" step="any" value="${it.qty}" aria-label="Quantity"></td>
      <td data-label="Unit price"><input data-k="rate" type="number" min="0" step="any" value="${it.rate}" aria-label="Unit price"></td>
      <td data-label="Amount" class="num amt">${money(line(it))}</td>
      <td><button type="button" class="icon-btn danger" data-remove aria-label="Remove item" title="Remove item">×</button></td>
    </tr>`).join("");
}
function renderTotals(c, t) {
  $("#lDisc").textContent = `Discount (${+c.discount || 0}%)`;
  $("#lTax").textContent = `Tax (${+c.tax || 0}%)`;
  $("#tSub").textContent = money(t.sub);
  $("#tDisc").textContent = (t.disc ? "−" : "") + money(t.disc);
  $("#tTax").textContent = money(t.tax);
  $("#tTotal").textContent = money(t.total);
}
const COMPANY = { name: "Northwind Studio", tagline: "Design & Development", lines: ["12 Market Street, Springfield", "hello@northwind.studio", "+1 555 010 0000", "www.northwind.studio"] };

function invoiceHTML(c) {
  const t = totals(c), s = statusOf(c);
  const billed = [c.email, c.phone, c.address].filter(Boolean).map(esc).join("\n");
  const statusNote = { paid: "Payment received. Thank you.", pending: `Payment due by ${fmtDate(c.due)}.`, overdue: `Payment was due on ${fmtDate(c.due)}.` }[s];
  return `<div class="inv-page">
    <header class="inv-head">
      <div class="biz">
        <span class="biz-logo" aria-hidden="true">${esc(COMPANY.name.charAt(0))}</span>
        <div><div class="co">${esc(COMPANY.name)}</div><div class="muted">${esc(COMPANY.tagline)}</div></div>
      </div>
      <div class="inv-title"><h2>Invoice</h2><div class="muted">${esc(c.number)}</div></div>
    </header>
    <div class="biz-contact muted">${COMPANY.lines.map(esc).join("  ·  ")}</div>

    <section class="inv-info">
      <div class="info-block"><b>Billed to</b><span class="strong">${esc(c.client) || "<span class='muted'>Client name</span>"}</span><div class="muted">${billed}</div></div>
      <div class="info-block">
        <b>Invoice details</b>
        <dl>
          <div><dt>Invoice no.</dt><dd>${esc(c.number)}</dd></div>
          <div><dt>Invoice date</dt><dd>${fmtDate(c.issued)}</dd></div>
          <div><dt>Due date</dt><dd>${fmtDate(c.due)}</dd></div>
          <div><dt>Payment status</dt><dd><span class="badge ${s}">${s}</span></dd></div>
        </dl>
      </div>
    </section>

    <table class="lines"><thead><tr><th class="idx">#</th><th>Product / service</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr></thead>
    <tbody>${c.items.map((i, n) => `<tr><td class="idx">${n + 1}</td><td>${esc(i.description) || "—"}</td><td class="num">${+i.qty || 0}</td><td class="num">${money(i.rate)}</td><td class="num">${money(line(i))}</td></tr>`).join("")}</tbody></table>

    <section class="inv-bottom">
      <div class="pay-box">
        <b>Payment status</b>
        <div class="pay-state ${s}"><span class="badge ${s}">${s}</span><span class="muted">${statusNote}</span></div>
        ${c.notes ? `<b class="nb">Notes</b><div class="muted">${esc(c.notes)}</div>` : ""}
      </div>
      <div class="totals">
        <div><span>Subtotal</span><span>${money(t.sub)}</span></div>
        <div><span>Discount (${+c.discount || 0}%)</span><span>${t.disc ? "−" : ""}${money(t.disc)}</span></div>
        <div><span>Tax (${+c.tax || 0}%)</span><span>${money(t.tax)}</span></div>
        <div class="grand"><span>Grand total</span><span>${money(t.total)}</span></div>
      </div>
    </section>

    <footer class="inv-foot"><span>Thank you for your business.</span><span>${esc(COMPANY.name)} · ${esc(COMPANY.lines[1])}</span></footer>
  </div>`;
}
function renderPreview() {
  renderTotals(current, totals(current));
  $("#preview").innerHTML = invoiceHTML(current);
}

/* ---------- Print & PDF ---------- */
function printInvoice(inv) {
  $("#printArea").innerHTML = `<article class="invoice">${invoiceHTML(inv)}</article>`;
  const prev = document.title;
  document.title = inv.number;               // used as the default file name in "Save as PDF"
  const restore = () => { document.title = prev; $("#printArea").innerHTML = ""; window.removeEventListener("afterprint", restore); };
  window.addEventListener("afterprint", restore);
  window.print();
}

function downloadPDF(inv) {
  const jsPDF = window.jspdf && window.jspdf.jsPDF;
  if (!jsPDF || !jsPDF.API.autoTable) { toast("PDF tool didn't load, opening print dialog instead"); return printInvoice(inv); }
  const t = totals(inv), s = statusOf(inv), doc = new jsPDF({ unit: "mm", format: "a4" });
  const M = 18, W = 210, R = W - M, INK = [21, 35, 31], MUTED = [95, 113, 107], GREEN = [14, 107, 85], LINE = [219, 227, 224];
  const pdfMoney = n => money(n);                          // standard PDF fonts have no "−", so a plain hyphen is used below
  const text = (str, x, y, o = {}) => doc.text(String(str), x, y, o);
  const set = (size, color, style = "normal") => { doc.setFontSize(size); doc.setTextColor(...color); doc.setFont("helvetica", style); };

  // Header
  set(26, GREEN, "bold"); text("Invoice", M, M + 8);
  set(10, MUTED); text(inv.number, M, M + 14);
  set(12, INK, "bold"); text(COMPANY.name, R, M + 4, { align: "right" });
  set(9, MUTED); COMPANY.lines.forEach((l, n) => text(l, R, M + 10 + n * 4.5, { align: "right" }));
  doc.setDrawColor(...GREEN); doc.setLineWidth(0.8); doc.line(M, M + 24, R, M + 24);

  // Status pill
  const label = s.toUpperCase();
  const pill = { paid: [[223, 242, 236], GREEN], pending: [[253, 240, 213], [161, 92, 0]], overdue: [[251, 227, 225], [179, 38, 30]] }[s];
  set(8, pill[1], "bold");
  const pw = doc.getTextWidth(label) + 8;
  doc.setFillColor(...pill[0]); doc.roundedRect(R - pw, M + 17, pw, 6, 3, 3, "F");
  text(label, R - pw / 2, M + 21.2, { align: "center" });

  // Meta
  let y = M + 36;
  set(8, MUTED, "bold"); text("BILLED TO", M, y); text("INVOICE DATE", 120, y); text("DUE DATE", 160, y);
  set(11, INK, "bold"); text(inv.client || "—", M, y + 6);
  set(10, INK); text(fmtDate(inv.issued), 120, y + 6); text(fmtDate(inv.due), 160, y + 6);
  set(9, MUTED);
  const addr = doc.splitTextToSize([inv.email, inv.phone, inv.address].filter(Boolean).join("\n"), 90);
  addr.forEach((l, n) => text(l, M, y + 11.5 + n * 4.5));
  y += 14 + addr.length * 4.5;

  // Items
  doc.autoTable({
    startY: y + 4, margin: { left: M, right: M, bottom: 24 }, theme: "plain",
    head: [["Product / service", "Qty", "Rate", "Amount"]],
    body: inv.items.map(i => [i.description || "—", String(+i.qty || 0), pdfMoney(+i.rate || 0), pdfMoney(line(i))]),
    styles: { font: "helvetica", fontSize: 10, textColor: INK, cellPadding: { top: 3.5, bottom: 3.5, left: 2, right: 2 }, lineColor: LINE, lineWidth: 0 },
    headStyles: { fontSize: 8.5, fontStyle: "bold", textColor: MUTED, fillColor: [244, 247, 246] },
    columnStyles: { 1: { halign: "right", cellWidth: 20 }, 2: { halign: "right", cellWidth: 32 }, 3: { halign: "right", cellWidth: 34 } },
    didParseCell: d => { if (d.section === "head" && d.column.index > 0) d.cell.styles.halign = "right"; },
    didDrawCell: d => { if (d.section === "body") { doc.setDrawColor(...LINE); doc.setLineWidth(0.2); doc.line(d.cell.x, d.cell.y + d.cell.height, d.cell.x + d.cell.width, d.cell.y + d.cell.height); } }
  });

  // Totals (keep together on one page)
  let ty = doc.lastAutoTable.finalY + 8;
  if (ty > 297 - 24 - 36) { doc.addPage(); ty = M; }
  const lx = R - 70;
  [["Subtotal", pdfMoney(t.sub)], [`Discount (${+inv.discount || 0}%)`, (t.disc ? "- " : "") + pdfMoney(t.disc)], [`Tax (${+inv.tax || 0}%)`, pdfMoney(t.tax)]].forEach(([k, v], n) => {
    set(10, MUTED); text(k, lx, ty + n * 6); set(10, INK); text(v, R, ty + n * 6, { align: "right" });
  });
  ty += 19;
  doc.setDrawColor(...INK); doc.setLineWidth(0.5); doc.line(lx, ty - 5, R, ty - 5);
  set(12, INK, "bold"); text("Grand total", lx, ty + 2); text(pdfMoney(t.total), R, ty + 2, { align: "right" });

  // Notes
  if (inv.notes) {
    ty += 16;
    const lines = doc.splitTextToSize(inv.notes, R - M);
    if (ty + 8 + lines.length * 4.5 > 297 - 24) { doc.addPage(); ty = M; }
    doc.setDrawColor(...LINE); doc.setLineWidth(0.2); doc.line(M, ty - 5, R, ty - 5);
    set(8, MUTED, "bold"); text("NOTES", M, ty);
    set(9.5, MUTED); lines.forEach((l, n) => text(l, M, ty + 5.5 + n * 4.5));
  }

  // Footer on every page
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setDrawColor(...LINE); doc.setLineWidth(0.2); doc.line(M, 281, R, 281);
    set(8.5, MUTED); text("Thank you for your business.", M, 286); text(`${inv.number}  ·  Page ${p} of ${pages}`, R, 286, { align: "right" });
  }
  doc.save(`${inv.number}.pdf`);
  toast(`${inv.number}.pdf downloaded`);
}

/* ---------- Events ---------- */
$$(".tab").forEach(t => t.addEventListener("click", () => {
  if (t.dataset.view === "editor" && !current) return openEditor();
  show(t.dataset.view);
}));
$("#newBtn").addEventListener("click", () => openEditor());
$("#cancel").addEventListener("click", () => { current = null; show("dashboard"); });
$("#search").addEventListener("input", renderList);
$("#filter").addEventListener("change", renderList);
$("#scope").addEventListener("change", renderList);
$("#sort").addEventListener("change", renderList);
$("#print").addEventListener("click", () => printInvoice(current));
$("#pdf").addEventListener("click", () => downloadPDF(current));

$("#rows").addEventListener("click", e => {
  const btn = e.target.closest("[data-act]");
  if (!btn) { const tr = e.target.closest("tr[data-id]"); if (tr) viewInvoice(tr.dataset.id); return; }
  const id = btn.closest("tr").dataset.id, inv = invoices.find(i => i.id === id);
  if (btn.dataset.act === "edit") openEditor(id);
  if (btn.dataset.act === "print") printInvoice(inv);
  if (btn.dataset.act === "pdf") downloadPDF(inv);
  if (btn.dataset.act === "paid") { inv.status = "paid"; persist(); renderList(); toast(`${inv.number} marked as paid`); }
  if (btn.dataset.act === "view") viewInvoice(id);
  if (btn.dataset.act === "delete") deleteInvoice(inv);
});

$("#form").addEventListener("input", e => {
  const el = e.target, row = el.closest(".item-row");
  if (row) {
    const it = current.items[row.dataset.n];
    it[el.dataset.k] = el.dataset.k === "description" ? el.value : Math.max(0, parseFloat(el.value) || 0);
    $(".amt", row).textContent = money(line(it));
    if ($("#itemsErr").textContent) checkItems();
  } else if (el.name) {
    current[el.name] = ["tax", "discount"].includes(el.name) ? Math.min(100, Math.max(0, parseFloat(el.value) || 0)) : el.value;
    if (el.classList.contains("invalid")) check(el);
    if (el.name === "issued") check(el.form.elements.due);
  }
  renderPreview();
});
$("#addItem").addEventListener("click", () => {
  current.items.push({ description: "", qty: 1, rate: 0 }); renderItems(); renderPreview();
  $$("#items .item-row:last-child input")[0].focus();
});
$("#items").addEventListener("click", e => {
  if (!e.target.matches("[data-remove]")) return;
  if (current.items.length === 1) return toast("An invoice needs at least one line item");
  current.items.splice(e.target.closest(".item-row").dataset.n, 1); renderItems(); renderPreview();
});

/* ---------- Validation ---------- */
const rules = {
  client: v => !v ? "Enter the customer's name." : v.length < 2 ? "Name must be at least 2 characters." : "",
  email: v => !v ? "Enter an email address." : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "Enter a valid email, like name@company.com." : "",
  phone: v => { if (!v) return ""; const d = v.replace(/\D/g, "").length; return /^\+?[\d\s().-]+$/.test(v) && d >= 7 && d <= 15 ? "" : "Enter a valid phone number, like +1 555 123 4567."; },
  address: v => !v ? "Enter the billing address." : v.length < 5 ? "Address is too short." : "",
  issued: v => v ? "" : "Choose an invoice date.",
  due: (v, f) => !v ? "Choose a due date." : v < f.elements.issued.value ? "Due date can't be before the invoice date." : "",
  tax: v => v === "" || (+v >= 0 && +v <= 100) ? "" : "Enter a percentage between 0 and 100.",
  discount: v => v === "" || (+v >= 0 && +v <= 100) ? "" : "Enter a percentage between 0 and 100."
};
function setError(el, msg) {
  const box = el.closest("label");
  let e = $(".err", box);
  if (!e) { e = document.createElement("span"); e.className = "err"; e.id = `err-${el.name}`; box.append(e); el.setAttribute("aria-describedby", e.id); }
  e.textContent = msg; el.classList.toggle("invalid", !!msg); el.setAttribute("aria-invalid", !!msg);
}
function check(el) {
  const msg = rules[el.name](el.value.trim(), el.form);
  setError(el, msg); return !msg;
}
function checkItems() {
  let ok = true;
  $$(".item-row").forEach((row, n) => {
    const it = current.items[n], d = $('[data-k="description"]', row), q = $('[data-k="qty"]', row);
    const badD = !it.description.trim(), badQ = !(it.qty > 0);
    d.classList.toggle("invalid", badD); q.classList.toggle("invalid", badQ);
    if (badD || badQ) ok = false;
  });
  $("#itemsErr").textContent = ok ? "" : "Each line item needs a description and a quantity above 0.";
  return ok;
}
$("#form").addEventListener("focusout", e => { if (rules[e.target.name]) check(e.target); });

$("#form").addEventListener("submit", e => {
  e.preventDefault();
  const bad = $$("[name]", e.target).filter(el => rules[el.name] && !check(el));
  const itemsOk = checkItems();
  const first = bad[0] || (itemsOk ? null : $(".item-row .invalid"));
  if (first) { first.focus(); return toast("Fix the highlighted fields to save"); }
  ["number", "client", "email", "phone", "address", "notes"].forEach(k => (current[k] = (current[k] || "").trim()));
  if (isNew) current.number = nextNumber();
  const at = invoices.findIndex(i => i.id === current.id);
  at >= 0 ? (invoices[at] = current) : invoices.push(current);
  persist(); toast(`${current.number} saved`); current = null; renderList(); show("dashboard");
});

$("#createBtn").addEventListener("click", () => openEditor());
$("#viewAll").addEventListener("click", () => show("list"));
const openRecent = e => {
  const li = e.target.closest("li[data-id]");
  if (li && (e.type === "click" || e.key === "Enter")) openEditor(li.dataset.id);
};
$("#recent").addEventListener("click", openRecent);
$("#recent").addEventListener("keydown", openRecent);

renderList();
